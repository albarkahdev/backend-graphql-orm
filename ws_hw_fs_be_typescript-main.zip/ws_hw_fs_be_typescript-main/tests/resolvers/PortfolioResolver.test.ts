import PortfolioEntity from '../../src/entities/PortfolioEntity';
import createApolloServer from '../test_helpers/createApolloServer';
import createPortfolioEntity from '../test_helpers/createPortfolioHelper';

describe('PortfolioResolver', () => {
  const QUERY_LIST_PORTFOLIOS = `
    query ListPortfolios {
      listPortfolios {
        id
        name
        url
      }
    }
  `;

  const MUTATION_ADD_PORTFOLIO = `
    mutation AddPortfolio($name: String!, $url: String!) {
      addPortfolio(name: $name, url: $url) {
        id
        name
        url
      }
    }
  `;

  const MUTATION_UPDATE_PORTFOLIO = `
    mutation UpdatePortfolio($id: Int!, $name: String, $url: String) {
      updatePortfolio(id: $id, name: $name, url: $url) {
        id
        name
        url
      }
    }
  `;

  const MUTATION_DELETE_PORTFOLIO = `
    mutation DeletePortfolio($id: Int!) {
      deletePortfolio(id: $id)
    }
  `;

  let portfolio1: PortfolioEntity;
  let portfolio2: PortfolioEntity;
  let portfolio3: PortfolioEntity;

  beforeAll(async () => {
    portfolio1 = await createPortfolioEntity();
    portfolio2 = await createPortfolioEntity();
    portfolio3 = await createPortfolioEntity();
  });

  test('list portfolios', async () => {
    const server = createApolloServer();
    const response = await server.executeOperation({
      query: QUERY_LIST_PORTFOLIOS,
      variables: {},
    });
    expect(response).toGraphQLResponseData({
      listPortfolios: [
        {
          id: portfolio1.id,
          name: portfolio1.name,
          url: portfolio1.url,
        },
        {
          id: portfolio2.id,
          name: portfolio2.name,
          url: portfolio2.url,
        },
        {
          id: portfolio3.id,
          name: portfolio3.name,
          url: portfolio3.url,
        },
      ],
    });
  });

  test('add portfolio', async () => {
    const server = createApolloServer();
    const response = await server.executeOperation({
      query: MUTATION_ADD_PORTFOLIO,
      variables: {
        name: 'New Portfolio',
        url: 'http://newportfolio.com',
      },
    });
    expect(response).toGraphQLResponseData({
      addPortfolio: {
        id: 4,
        name: 'New Portfolio',
        url: 'http://newportfolio.com',
      },
    });
  });

  test('update portfolio', async () => {
    const server = createApolloServer();
    const response = await server.executeOperation({
      query: MUTATION_UPDATE_PORTFOLIO,
      variables: {
        id: 4,
        name: 'Updated Portfolio',
        url: 'http://updatedportfolio.com',
      },
    });
    expect(response).toGraphQLResponseData({
      updatePortfolio: {
        id: 4,
        name: 'Updated Portfolio',
        url: 'http://updatedportfolio.com',
      },
    });
  });

  test('delete portfolio', async () => {
    const server = createApolloServer();
    const response = await server.executeOperation({
      query: MUTATION_DELETE_PORTFOLIO,
      variables: { id: 4 },
    });

    expect(response).toGraphQLResponseData({
      deletePortfolio: true,
    });

    const responseAll = await server.executeOperation({
      query: QUERY_LIST_PORTFOLIOS,
      variables: {},
    });
    expect(responseAll).toGraphQLResponseData({
      listPortfolios: [
        {
          id: portfolio1.id,
          name: portfolio1.name,
          url: portfolio1.url,
        },
        {
          id: portfolio2.id,
          name: portfolio2.name,
          url: portfolio2.url,
        },
        {
          id: portfolio3.id,
          name: portfolio3.name,
          url: portfolio3.url,
        },
      ],
    });
  });
});
