import PortfolioVersionEntity from '../../src/entities/PortfolioVersionEntity';
import PortfolioEntity from '../../src/entities/PortfolioEntity';
import createApolloServer from '../test_helpers/createApolloServer';
import createPortfolioVersionEntity from '../test_helpers/createPortfolioVersionHelper';
import createPortfolioEntity from '../test_helpers/createPortfolioHelper';

describe('PortfolioVersionResolver', () => {
  const QUERY_LIST_PORTFOLIO_VERSIONS = `
    query ListPortfolioVersions($portfolioId: Int!) {
      listPortfolioVersions(portfolioId: $portfolioId) {
        id
        versionType
      }
    }
  `;

  const MUTATION_ADD_PORTFOLIO_VERSION = `
    mutation AddPortfolioVersion($portfolioId: Int!, $versionType: String!) {
      addPortfolioVersion(portfolioId: $portfolioId, versionType: $versionType) {
        id
        versionType
      }
    }
  `;

  const MUTATION_UPDATE_PORTFOLIO_VERSION = `
    mutation UpdatePortfolioVersion($id: Int!, $versionType: String, $pages: [PageInput!]) {
      updatePortfolioVersion(id: $id, versionType: $versionType, pages: $pages) {
        id
        versionType
      }
    }
  `;

  const MUTATION_DELETE_PORTFOLIO_VERSION = `
    mutation DeletePortfolioVersion($id: Int!) {
      deletePortfolioVersion(id: $id)
    }
  `;

  let portfolio: PortfolioEntity;
  let version1: PortfolioVersionEntity;
  let version2: PortfolioVersionEntity;

  beforeAll(async () => {
    portfolio = await createPortfolioEntity();
    version1 = await createPortfolioVersionEntity({ portfolio });
    version2 = await createPortfolioVersionEntity({ portfolio });
  });

  test('list portfolio versions', async () => {
    const server = createApolloServer();
    const response = await server.executeOperation({
      query: QUERY_LIST_PORTFOLIO_VERSIONS,
      variables: { portfolioId: portfolio.id },
    });
    expect(response).toGraphQLResponseData({
      listPortfolioVersions: [
        {
          id: version1.id,
          versionType: version1.versionType,
        },
        {
          id: version2.id,
          versionType: version2.versionType,
        },
      ],
    });
  });

  test('add portfolio version', async () => {
    const server = createApolloServer();
    const response = await server.executeOperation({
      query: MUTATION_ADD_PORTFOLIO_VERSION,
      variables: {
        portfolioId: portfolio.id,
        versionType: 'New Version Type',
      },
    });
    expect(response).toGraphQLResponseData({
      addPortfolioVersion: {
        id: 3,
        versionType: 'New Version Type',
      },
    });
  });

  test('update portfolio version', async () => {
    const server = createApolloServer();
    const response = await server.executeOperation({
      query: MUTATION_UPDATE_PORTFOLIO_VERSION,
      variables: {
        id: 3,
        versionType: 'Updated Version Type',
      },
    });
    expect(response).toGraphQLResponseData({
      updatePortfolioVersion: {
        id: 3,
        versionType: 'Updated Version Type',
      },
    });
  });

  test('delete portfolio version', async () => {
    const server = createApolloServer();
    const response = await server.executeOperation({
      query: MUTATION_DELETE_PORTFOLIO_VERSION,
      variables: { id: 3 },
    });

    expect(response).toGraphQLResponseData({
      deletePortfolioVersion: true,
    });

    const responseAll = await server.executeOperation({
      query: QUERY_LIST_PORTFOLIO_VERSIONS,
      variables: { portfolioId: portfolio.id },
    });
    expect(responseAll).toGraphQLResponseData({
      listPortfolioVersions: [
        {
          id: version1.id,
          versionType: version1.versionType,
        },
        {
          id: version2.id,
          versionType: version2.versionType,
        },
      ],
    });
  });
});
